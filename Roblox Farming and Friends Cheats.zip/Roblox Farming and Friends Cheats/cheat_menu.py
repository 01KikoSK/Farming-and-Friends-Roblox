from flask import Flask, render_template, request

app = Flask(__name__)

cheats = {
    "spawn_item": {"name": "Spawn Item", "action": "spawn_item"},
    "infinite_resources": {"name": "Infinite Resources", "action": "infinite_resources"},
    # Add more cheats here
}

@app.route('/')
def index():
    return render_template('index.html', cheats=cheats)

@app.route('/cheat', methods=['POST'])
def cheat():
    action = request.form.get('action')
    if action == 'spawn_item':
        # Implement the spawn item cheat here
        pass
    elif action == 'infinite_resources':
        # Implement the infinite resources cheat here
        pass
    # Add more cheats here
    return "Cheat activated!"

if __name__ == '__main__':
    app.run(host='0.0.0.0',port='1111',debug=False)